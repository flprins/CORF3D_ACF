function clr

evalin('base','clear all')
close all
clc

return