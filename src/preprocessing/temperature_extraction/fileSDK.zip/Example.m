clr;
addpath('I:\Code\fileSDK');

dataPath = 'I:\Code\Mean_Otsu_Comparison\Images';

[frames, files] = readPTW(dataPath);